# Crybot-Commands
These comamnds are Crybot's and we are sharing them to help you make your bot a bit like Crybot.
If you want to join Crybot's Development server for help about the Commands the link is here: https://discord.gg/TkpeeX9

©2018-2020 Crybot Development
